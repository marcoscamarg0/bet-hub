import { useState, useRef, useEffect } from 'react';
import styles from './MemeWheel.module.css';

interface WheelItem {
  id: string;
  name: string;
  color: string;
  weight?: number; // Chance relativa (default: 1)
  fake?: boolean; // Se true, gira lentamente para outro item
  redirectTo?: string; // id do item para redirecionar quando fake
}

// ── EDITE AQUI OS ITENS DA ROLETA ──────────────────────────────
// Quanto maior o weight, maior a chance de ganhar
// fake: true + redirectTo: '4' = quando cair nele, gira lento para o id 4
const DEFAULT_ITEMS: WheelItem[] = [
  { id: '1', name: 'VOCÊ GANHOU R$1000 reais🎉', color: '#FF6B6B', weight: 10, fake: true, redirectTo: '4' },
  { id: '2', name: 'TENTE NOVAMENTE', color: '#4ECDC4', weight: 50 },
  { id: '3', name: 'MISERÁVEL 💀', color: '#FFE66D', weight: 30 },
  { id: '4', name: 'VOCÊ GANHOU UMA JATADA NA CARA 🚀', color: '#95E1D3', weight: 50 },
];

export function MemeWheel() {
  const items = DEFAULT_ITEMS; // Edite aqui os itens da roleta
  const [isExpanded, setIsExpanded] = useState(false);
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [winner, setWinner] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Draw wheel
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 5;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Calcular total de pesos
    const totalWeight = items.reduce((sum, item) => sum + (item.weight || 1), 0);

    let currentAngle = rotation;

    // Draw segments
    items.forEach((item) => {
      const sliceAngle = ((item.weight || 1) / totalWeight) * 360 * (Math.PI / 180);
      const startAngle = currentAngle;
      const endAngle = currentAngle + sliceAngle;

      // Draw segment
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      ctx.closePath();
      ctx.fillStyle = item.color;
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.3)';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Draw text
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(startAngle + sliceAngle / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = 'rgba(0,0,0,0.8)';
      ctx.font = 'bold 12px Arial';
      ctx.fillText(item.name, radius - 20, 5);
      ctx.restore();

      currentAngle = endAngle;
    });

    // Draw center circle
    ctx.beginPath();
    ctx.arc(centerX, centerY, 30, 0, 2 * Math.PI);
    ctx.fillStyle = '#fff';
    ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.3)';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Draw pointer
    ctx.beginPath();
    ctx.moveTo(centerX - 10, centerY - radius - 5);
    ctx.lineTo(centerX + 10, centerY - radius - 5);
    ctx.lineTo(centerX, centerY - radius + 10);
    ctx.closePath();
    ctx.fillStyle = '#FF6B6B';
    ctx.fill();
  }, [rotation, items]);

  const spin = () => {
    if (isSpinning || items.length === 0) return;

    setIsSpinning(true);
    setWinner(null);

    const spins = 5 + Math.random() * 5; // 5-10 full rotations
    const randomDegree = Math.random() * 360;
    const totalRotation = spins * 360 + randomDegree;

    let current = rotation;
    const duration = 4000; // 4 seconds
    const startTime = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Easing out (decelerate)
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      current = rotation + totalRotation * easeProgress;
      setRotation(current % 360);

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setIsSpinning(false);
        // Determine winner
        const normalizedRotation = (360 - (current % 360)) % 360;
        const totalWeight = items.reduce((sum, item) => sum + (item.weight || 1), 0);

        let accumulatedAngle = 0;
        let winnerIndex = 0;

        for (let i = 0; i < items.length; i++) {
          const segmentAngle = ((items[i].weight || 1) / totalWeight) * 360;
          if (normalizedRotation < accumulatedAngle + segmentAngle) {
            winnerIndex = i;
            break;
          }
          accumulatedAngle += segmentAngle;
        }

        // Se ganhou um item fake, girar lentamente para o redirectTo
        if (items[winnerIndex].fake && items[winnerIndex].redirectTo) {
          const targetId = items[winnerIndex].redirectTo;
          const targetItem = items.find(item => item.id === targetId);
          
          if (targetItem) {
            // Calcular o ângulo do item de destino
            let targetAccAngle = 0;
            for (let i = 0; i < items.length; i++) {
              if (items[i].id === targetId) break;
              targetAccAngle += ((items[i].weight || 1) / totalWeight) * 360;
            }
            
            // Calcular rotação mínima para chegar ao item (centralizar na rodinha)
            const midSegmentAngle = ((targetItem.weight || 1) / totalWeight) * 180;
            const targetRotation = 360 - (targetAccAngle + midSegmentAngle);
            
            // Girar lentamente (8 segundos)
            setIsSpinning(true);
            const slowDuration = 3000;
            const slowStartTime = Date.now();
            
            const slowAnimate = () => {
              const slowElapsed = Date.now() - slowStartTime;
              const slowProgress = Math.min(slowElapsed / slowDuration, 1);
              
              // Easing suave
              const easeProgress = slowProgress < 0.5 
                ? 2 * slowProgress * slowProgress 
                : -1 + (4 - 2 * slowProgress) * slowProgress;
              
              const diff = ((targetRotation - (current % 360)) + 360) % 360;
              const newRotation = current + diff * easeProgress;
              setRotation(newRotation % 360);
              
              if (slowProgress < 1) {
                requestAnimationFrame(slowAnimate);
              } else {
                setIsSpinning(false);
                setWinner(targetItem.name);
              }
            };
            
            requestAnimationFrame(slowAnimate);
            return;
          }
        }

        setWinner(items[winnerIndex].name);
      }
    };

    requestAnimationFrame(animate);
  };

  if (!isExpanded) {
    return (
      <button
        className={styles.wheelButton}
        onClick={() => setIsExpanded(true)}
        title="Abrir roleta meme"
      >
        🎡
      </button>
    );
  }

  return (
    <div className={styles.wheelContainer}>
      <div className={styles.wheelHeader}>
        <h2>🎡 Roleta Meme</h2>
        <button
          className={styles.closeBtn}
          onClick={() => setIsExpanded(false)}
        >
          ✕
        </button>
      </div>

      <div className={styles.wheelContent}>
        <canvas
          ref={canvasRef}
          width={300}
          height={300}
          className={isSpinning ? styles.wheelSpinning : ''}
        />
        <button
          className={styles.spinBtn}
          onClick={spin}
          disabled={isSpinning}
        >
          {isSpinning ? 'GIRANDO...' : 'GIRAR! 🎲'}
        </button>
        {winner && (
          <div className={styles.winnerDisplay}>
            🏆 {winner}
          </div>
        )}
      </div>
    </div>
  );
}